
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCYNMnpdp_Fn3s_sa36ZeY28axW7V2xrKM",
  authDomain: "webcarros-300bc.firebaseapp.com",
  projectId: "webcarros-300bc",
  storageBucket: "webcarros-300bc.appspot.com",
  messagingSenderId: "458959533672",
  appId: "1:458959533672:web:c8568f71b870c8ab3e6ddd"
};
const app = initializeApp(firebaseConfig);

const db = getFirestore(app)
const auth = getAuth(app)
const storage = getStorage(app)

export { db, auth, storage }