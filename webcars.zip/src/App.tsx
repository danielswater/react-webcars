import { createBrowserRouter } from "react-router-dom";
import CarDetails from "./pages/car/car";
import Dashboard from "./pages/dashboard/dashboard";
import New from "./pages/dashboard/new/new";
import Home from "./pages/home/home";
import Login from "./pages/login/login";
import Register from "./pages/register/register";
import Layout from "./components/layout/layout";
import Private from "./routes/Private";

export const router = createBrowserRouter([
    {
        element: <Layout />, children: [
            { path: '/', element: <Home /> },
            { path: '/car/:id', element: <CarDetails /> },
            { path: '/dashboard', element: <Private><Dashboard /></Private> },
            { path: '/dashboard/new', element: <Private><New /></Private> }
        ]
    },
    { path: '/login', element: <Login /> },
    { path: '/register', element: <Register /> }
])